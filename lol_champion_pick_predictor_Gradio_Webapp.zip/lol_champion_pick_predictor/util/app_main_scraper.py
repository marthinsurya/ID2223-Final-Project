from Recent_match_scrapper import get_matches_stats
import os
import pandas as pd
import numpy as np
from Meta_scrapper import *
from helper import merge_stats,  process_kda_perfect, ChampionConverter
from Player_scrapper import get_player_stats
from Weekly_meta_scrapper import *
import pandas as pd
import re


meta_stats = get_meta_stats() 
weekly_meta_stats = get_weekly_meta()

# Sample data
data = {
    'username': ['cat goes meow #silly'],
    'region': ['vn']
}

# Create DataFrame
player_df = pd.DataFrame(data)


player_stats = get_multiple_player_stats(player_df)    #save to player_stats.csv
recent_stats = get_multiple_matches_stats(player_df)   #save to recent_stats.csv
merged_stats = merge_stats(recent_stats, player_stats)          #save to player_stats_merged.csv

#feature engineering
training_features = create_champion_features(merged_player_stats=merged_stats, debug=None, consider_team_comp=True, test_mode=False)   #save to feature_eng_stats.csv