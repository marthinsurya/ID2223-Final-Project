#!/bin/bash
apt-get update
apt-get install -y chromium-browser chromium-chromedriver
chmod -R 777 /usr/lib/chromium
chmod -R 777 /usr/bin/chromedriver