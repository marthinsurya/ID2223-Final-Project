---
title: League Champion Pick Predictor
emoji: 🎮
colorFrom: blue
colorTo: red
sdk: gradio
sdk_version: "4.19.2"
app_file: util/app.py
pinned: false
hardware: true
dockerfile: true
---

# League of Legends Champion Prediction

This Gradio app predicts the final champion pick in a League of Legends game based on the current team composition.

## Features
- Player statistics lookup
- Recent match history display
- Champion prediction based on current team composition
- Interactive interface with champion selection dropdowns

## Usage
1. Enter player name
2. Click "Show Stats" to view player statistics
3. Select 9 champions using the dropdowns
4. Click "Predict" to get the prediction for the final champion